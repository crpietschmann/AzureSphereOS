/*
#dynamic:
#sim: --sysroot=@exedir@ --load-vma
 */
#include "hello.c"
