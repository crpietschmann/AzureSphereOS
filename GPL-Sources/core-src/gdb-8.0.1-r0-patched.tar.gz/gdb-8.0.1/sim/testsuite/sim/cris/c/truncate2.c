/*
#sim: --sysroot=@exedir@
#notarget: cris*-*-elf
*/
#define PREFIX "/"
#include "truncate1.c"
