W,
r,a8832,abcdef01
w,a8836,aabbccdd
r,a8836,76543210
