/* Simulator options:
#notarget: cris*-*-elf
#sim: --sysroot=@exedir@
*/
#define SYSROOTED 1
#include "readlink2.c"
